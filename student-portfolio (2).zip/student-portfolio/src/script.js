let student = {

    name: "Sandhiya",

    age: 20,

    marks: [85, 90, 92],

    average: function() {

        let sum = this.marks.reduce((a, b) => a + b, 0);

        return sum / this.marks.length;

    }

};

console.log("Name: " + student.name);

console.log("Age: " + student.age);

console.log("Average Marks: " + student.average());